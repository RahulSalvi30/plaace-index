export { Img } from "./Img";
export { Text } from "./Text";
